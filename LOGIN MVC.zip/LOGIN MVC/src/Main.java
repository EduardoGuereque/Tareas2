
public class Main{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AuthView vista = new AuthView();
        AuthModel modelo = new AuthModel();
        new AuthController(vista, modelo);

	}

}

