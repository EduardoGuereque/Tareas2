import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;

public class AuthController {
    private AuthView vista;
    private AuthModel modelo;

    public AuthController(AuthView vista, AuthModel modelo) {
        this.vista = vista;
        this.modelo = modelo;

        this.vista.getBtnLogin().addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String usuario = vista.getUsuario();
                String contrasena = vista.getContrasena();

                if (modelo.autenticar(usuario, contrasena)) {
                	vista.lblMensaje.setForeground(Color.green);
                    vista.mostrarMensaje("Login realizado correctamnte");
                    vista.usuario.setBorder(BorderFactory.createLineBorder(Color.GREEN, 3));
                    vista.contrasena.setBorder(BorderFactory.createLineBorder(Color.GREEN, 3));
                } else {
                	vista.lblMensaje.setForeground(Color.red);
                    vista.mostrarMensaje("Usuario o contraseña incorrecta");
                    vista.usuario.setBorder(BorderFactory.createLineBorder(Color.RED, 3));
                    vista.contrasena.setBorder(BorderFactory.createLineBorder(Color.RED, 3));
                }
            }
        });

        this.vista.mostrar();
    }
}

