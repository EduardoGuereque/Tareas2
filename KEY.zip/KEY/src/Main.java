import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.SystemColor;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Random;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.Rectangle;
import javax.swing.JLabel;

public class Main {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main window = new Main();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Main() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private int x = 200;
	private int y = 200;
	private int tam = 20;
	Graphics2D g2;
	private int r;
	private int gg;
	private int b;
	private Random random = new Random();
	private Color Colorin = Color.RED;
		
	private void initialize() {
	    frame = new JFrame();
	    frame.setBounds(150, 50, 715, 600);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.getContentPane().setLayout(null);
	    
	    PaintPanel paintPanel = new PaintPanel();
	    paintPanel.setBounds(0, 39, 701, 486);
	    frame.getContentPane().add(paintPanel);
	    
	    JPanel panel_1 = new JPanel();
	    panel_1.setBounds(0, 0, 701, 39);
	    panel_1.setBackground(new Color(153, 204, 255));
	    frame.getContentPane().add(panel_1);
	    
	    JPanel panel_2 = new JPanel();
	    panel_2.setBounds(0, 524, 701, 39);
	    panel_2.setBackground(new Color(153, 204, 255));
	    frame.getContentPane().add(panel_2);
	    panel_2.setLayout(null);
	    
	    JButton btnNewButton = new JButton("Reiniciar");
	    btnNewButton.setBounds(303, 11, 89, 23);
	    btnNewButton.setBackground(new Color(255, 255, 153));
	    panel_2.add(btnNewButton);
	}
		

	class PaintPanel extends JPanel {
	    public PaintPanel() {
	        this.setBackground(new Color(228, 228, 228));
	        this.setFocusable(true);
	        this.requestFocusInWindow();
	        this.setLayout(null);
	        
	        this.addKeyListener(new KeyAdapter() {
	            @Override
	            public void keyPressed(KeyEvent e) {
	                int tecla = e.getKeyCode();
	                int mov = 10;

	                switch (tecla) {
	                    case KeyEvent.VK_UP:
	                        y -= mov;
	                        break;
	                    case KeyEvent.VK_DOWN:
	                        y += mov;
	                        break;
	                    case KeyEvent.VK_LEFT:
	                        x -= mov;
	                        break;
	                    case KeyEvent.VK_RIGHT:
	                        x += mov;
	                        break;
	                    case KeyEvent.VK_SPACE:
	                    	Colorin = Colores();
	                        break;
	                }
	                repaint();
	            }
	        });
	    }
	    
	    private Color Colores() {
	        int r = random.nextInt(256);
	        int gg = random.nextInt(256);
	        int b = random.nextInt(256);
	        return new Color(r, gg, b);
	    }

	    @Override
	    public void paintComponent(Graphics g) {
	        super.paintComponent(g);
	        g2 = (Graphics2D) g;
	        
	        g2.setColor(Colorin);
	        g2.fillRect(x, y, tam, tam);
	        
	    }
	    
	}
}
